# Construction Lessons-Learned RAG System

A pragmatic, Python-only proof-of-concept for semantic search over construction project lessons learned using Retrieval-Augmented Generation (RAG).

## Architecture

This system implements a clean RAG pipeline:

```
Excel Data → Ingestion → Embedding → Vector Index → Retrieval → LLM → Answer
```

### Key Components

1. **Data Ingestion** (`src/ingest.py`)
   - Load lessons from Excel
   - Validate required fields
   - Normalize data

2. **Embedding** (`src/embeddings.py`)
   - Convert text to vectors
   - Currently uses stub embedder for testing
   - Swappable interface for OpenAI/Cohere/etc.

3. **Vector Index** (`src/index.py`)
   - FAISS-based similarity search
   - Cosine similarity via normalized vectors
   - Persistent storage

4. **Retrieval** (`src/retrieve.py`)
   - Semantic search with filtering
   - Metadata filtering (discipline, phase, etc.)
   - Score thresholding

5. **Generation** (`src/generate.py`)
   - Grounded prompt construction
   - LLM response generation
   - Citation enforcement

## Installation

```bash
# Clone/download the project
cd rag_poc

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Quick Start

### 1. Create Example Data

```bash
python data/create_example_data.py
```

This creates `data/example_lessons.xlsx` with 10 sample lessons.

### 2. Build Index

```bash
python -m src.app build --excel data/example_lessons.xlsx --index-dir ./index
```

This will:
- Load lessons from Excel
- Validate data
- Create embeddings
- Build FAISS index
- Save to `./index/` directory

### 3. Run Queries

**Single query:**
```bash
python -m src.app query \
  --index-dir ./index \
  --question "What mistakes have we seen with electrical work?"
```

**Interactive mode:**
```bash
python -m src.app interactive --index-dir ./index
```

Type questions interactively. Type 'quit' to exit.

## Excel Data Format

Your Excel file must contain these columns:

**Required:**
- `mistake` - What went wrong
- `reason` - Why it happened  
- `resolution` - How it was fixed
- `discipline` - Area of work (electrical, mechanical, civil, etc.)
- `project_type` - Type of project
- `phase` - Project phase (design, construction, etc.)

**Optional:**
- `lesson_id` - Unique ID (auto-generated if missing)
- `date` - When lesson was recorded
- `vendor` - Vendor/supplier involved

## Usage Examples

### Build index from your data
```bash
python -m src.app build \
  --excel /path/to/your_lessons.xlsx \
  --index-dir ./my_index
```

### Query for specific issues
```bash
# Discipline-specific
python -m src.app query \
  --question "Electrical coordination problems during construction" \
  --index-dir ./index

# Phase-specific  
python -m src.app query \
  --question "Design phase mistakes with HVAC" \
  --index-dir ./index

# General patterns
python -m src.app query \
  --question "What usually causes schedule delays?" \
  --index-dir ./index
```

### Interactive exploration
```bash
python -m src.app interactive --index-dir ./index

# Example session:
Question: Have we seen similar mistakes with piping?
Answer: Based on 2 retrieved lessons: ...

Question: What caused instrumentation issues?
Answer: Based on 3 retrieved lessons: ...
```

## Configuration

### Retrieval Parameters

Adjust in code or when calling functions:

```python
from src import Retriever, create_embedding_client, FAISSVectorIndex

# Load components
embedder = create_embedding_client(provider="stub")
index = FAISSVectorIndex.load("./index")

# Create retriever with custom settings
retriever = Retriever(
    embedder=embedder,
    index=index,
    default_k=8,           # Retrieve more results
    score_threshold=0.2    # Lower threshold = more permissive
)
```

### Metadata Filters

The system automatically detects filters from query text:

- **Disciplines**: electrical, mechanical, civil, piping, instrumentation, controls, structural, hvac
- **Phases**: design, procurement, construction, commissioning, startup, closeout
- **Project Types**: industrial, commercial, residential, infrastructure

You can also specify explicit filters:

```python
hits = retriever.retrieve(
    query="What mistakes occurred?",
    filters={"discipline": "Electrical", "phase": "Construction"}
)
```

## Connecting Real LLM (OpenAI)

Currently using stub implementations. To connect OpenAI:

### 1. Install OpenAI SDK
```bash
pip install openai python-dotenv
```

### 2. Set API Key
```bash
export OPENAI_API_KEY="sk-..."
# Or use .env file
```

### 3. Update Code

Replace stub embedder:
```python
from openai import OpenAI

class OpenAIEmbeddingClient:
    def __init__(self, api_key: str):
        self.client = OpenAI(api_key=api_key)
        self.model = "text-embedding-3-small"
    
    @property
    def embedding_dim(self):
        return 1536
    
    def embed_texts(self, texts):
        response = self.client.embeddings.create(
            input=texts,
            model=self.model
        )
        return np.array([d.embedding for d in response.data], dtype=np.float32)
```

Replace stub LLM:
```python
class OpenAILLMClient:
    def __init__(self, api_key: str):
        self.client = OpenAI(api_key=api_key)
        self.model = "gpt-4-turbo-preview"
    
    def generate(self, prompt, system_message=None, temperature=0.3):
        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        messages.append({"role": "user", "content": prompt})
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=1000
        )
        
        return response.choices[0].message.content
```

## Project Structure

```
rag_poc/
├── src/
│   ├── __init__.py          # Package exports
│   ├── models.py            # Lesson data model
│   ├── ingest.py            # Excel loading & validation
│   ├── embeddings.py        # Embedding clients
│   ├── index.py             # FAISS vector index
│   ├── retrieve.py          # Retrieval logic
│   ├── generate.py          # LLM prompting & generation
│   └── app.py               # CLI application
├── data/
│   ├── create_example_data.py
│   └── example_lessons.xlsx
├── tests/                   # Unit tests (TODO)
├── requirements.txt
└── README.md
```

## Design Principles

### 1. Clarity over Cleverness
- Explicit data models
- Deterministic filtering
- Debuggable components

### 2. Grounding & Traceability
- Answers cite specific lesson IDs
- Metadata preserved through pipeline
- Score thresholds prevent weak answers

### 3. Modularity
- Swappable embedders (stub → OpenAI)
- Swappable LLMs (stub → ChatGPT)
- Clean interfaces

### 4. Production-Ready Patterns
- Persistent index storage
- Validation at ingestion
- Error handling
- Logging for debugging

## Key Tradeoffs

| Decision | Tradeoff |
|----------|----------|
| 1 lesson = 1 document | Simple, explainable. May need chunking for very long lessons. |
| No reranking | Relies on embedding quality. Add reranker if needed. |
| Keyword-based filtering | Deterministic, debuggable. May miss synonyms. |
| FAISS over Chroma/Weaviate | Simpler, fewer dependencies. Less batteries-included. |
| Stub embeddings for POC | Fast iteration. Must replace for production. |

## Next Steps

### Immediate (POC)
- [x] Data ingestion from Excel
- [x] Vector indexing with FAISS
- [x] Basic retrieval with filtering
- [x] Grounded prompt construction
- [x] CLI interface

### Short-term (Production-ready)
- [ ] Connect OpenAI embeddings
- [ ] Connect ChatGPT API
- [ ] Add unit tests
- [ ] Calibrate score thresholds on real data
- [ ] Add reranking if needed
- [ ] Build web UI (Streamlit/Gradio)

### Medium-term (Scale)
- [ ] Chunking for long lessons
- [ ] Hybrid search (keyword + semantic)
- [ ] User feedback loop
- [ ] Analytics dashboard
- [ ] Multi-tenancy for different projects

## Troubleshooting

### FAISS installation issues
```bash
# Use conda if pip fails
conda install -c pytorch faiss-cpu
```

### Empty results
- Check score threshold (lower it)
- Verify embeddings are working
- Inspect retrieved scores: `python -m src.app query --question "..." -k 10`

### Slow queries
- FAISS is very fast (<1ms for 1000s of docs)
- Bottleneck is likely embedding or LLM
- Consider caching query embeddings

## Support

For questions or issues:
1. Check this README
2. Review code comments (extensively documented)
3. Run with `verbose=True` for debugging
4. Check example queries in `data/create_example_data.py`

## License

MIT License - use freely for your construction projects!
